// db2a4b410908431f9a92e36400b427e8
// https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
const weatherApi={
    key:"db2a4b410908431f9a92e36400b427e8",
    baseUrl:"https://api.openweathermap.org/data/2.5/weather"
}
//Event Listener function on keypress
let inputBar=document.getElementById("input-bar")
inputBar.addEventListener('keypress',(event)=>{
    if(event.key === 'Enter'){
        console.log(inputBar.value);
        getweatherReport(inputBar.value);//parameter passed
        document.querySelector('.weather-details-wrap').style.display="block";
        document.querySelector('.headline').style.display="none";
    }
})
//Get Weather Report
function getweatherReport(city){
    fetch(`${weatherApi.baseUrl}?q=${city}&appid=${weatherApi.key}&units=metric`).then(weather=>{
        return weather.json();
    }).then(showweatherReport);
}
//Show weather report
function showweatherReport(weather){
    console.log(weather) 
    let City=document.getElementById("city")
    City.textContent=`${weather.name}, ${weather.sys.country}`;
    let Temp=document.getElementById("temp-c")
    Temp.innerHTML=`${Math.round(weather.main.temp)}&deg;C`
    let weatherCondition=document.getElementById("weather-condition");
    weatherCondition.textContent=`${weather.weather[0].main}`
    let currentDate=document.getElementById("current-date")
    let todayDate=new Date();
    currentDate.textContent=dateManage(todayDate);
    let currentTime=document.getElementById("current-time")
    currentTime.textContent=timeManage(todayDate)
    let humidValue=document.getElementById("humid-value");
    humidValue.textContent=`${weather.main.humidity}${"%"}`;
    let windValue=document.getElementById("wind-value");
    windValue.textContent=`${Math.floor((weather.wind.speed)*3.6)}${"Km/h"}`
    if(weatherCondition.textContent=='Haze' || weatherCondition.textContent=='Mist'){
        document.getElementById("w-c-p").src="Weather-type-icon/Haze.png";
    }
    else if(weatherCondition.textContent=='Clear'){
        document.getElementById("w-c-p").src="Weather-type-icon/Clear.png";
    }
    else if(weatherCondition.textContent=='Rain'){
        document.getElementById("w-c-p").src="Weather-type-icon/Rain.png";
    }
    else if(weatherCondition.textContent=='Snow'){
        document.getElementById("w-c-p").src="Weather-type-icon/Snow.png";
    }
    else if(weatherCondition.textContent=='Thunderstorm'){
        document.getElementById("w-c-p").src="Weather-type-icon/Thunderstorm.png";
    }
    else if(weatherCondition.textContent=='Clouds'){
        document.getElementById("w-c-p").src="Weather-type-icon/Cloud.png";
    }


}

//Data Manage
function dateManage(dateArg){
    let days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    let months=["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
    let year=dateArg.getFullYear();
    let month=months[dateArg.getMonth()];
    let date=dateArg.getDate();
    let day=days[dateArg.getDay()];
    return `${date}  ${month} ${day}, ${year}`;
}
//Time Manage
function timeManage(timeArg){
    let hour=timeArg.getHours()
    let minute=timeArg.getMinutes()
    let timeFormat='IST';
    return `${hour} : ${minute} ${(timeFormat)}`
}
